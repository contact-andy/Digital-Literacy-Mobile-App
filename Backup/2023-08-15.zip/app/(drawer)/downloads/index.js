import { DrawerToggleButton } from "@react-navigation/drawer";
import { Drawer } from "expo-router/drawer";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  TouchableOpacity,
  View,
  RefreshControl,
} from "react-native";
import { Stack, useRouter, useSearchParams } from "expo-router";
import { Text, SafeAreaView } from "react-native";
import axios from "axios";

import { ScreenHeaderBtn, NearbyJobCard } from "../../../components";
import { COLORS, icons, SIZES } from "../../../constants";
import styles from "../../../styles/search";
import { SERVER } from "../../../constants/url";
import * as SQLite from "expo-sqlite";

const DownloadsPage = () => {
  const db = SQLite.openDatabase("db.testDb"); // returns Database object
  const params = { id: "Downloads" };
  const router = useRouter();
  const [downloadedVideo, setdownloadedVideo] = useState([]);

  const [searchResult, setSearchResult] = useState([]);
  const [searchLoader, setSearchLoader] = useState(false);
  const [searchError, setSearchError] = useState(null);
  const [page, setPage] = useState(1);
  const [pageLimit, setPageLimit] = useState(false);
  let newPage = page;

  const handleSearch = async (newPage) => {
    setSearchLoader(true);
    try {
      db.transaction((tx) => {
        tx.executeSql(
          "Select * from `videos` where base64 IS NOT NULL",
          null,
          (txObj, resultSet) => setSearchResult(resultSet.rows._array),
          (txObj, error) => console.log(error)
        );
      });
    } catch (error) {
      setSearchError(error);
      console.log(error);
    } finally {
      setSearchLoader(false);
    }
  };

  const handlePagination = (direction) => {
    // if (pageLimit === true) {
    //   console.log("Last Page");
    //   return;
    // }
    if (direction === "left" && page > 1) {
      setPage(page - 1);
      newPage = page - 1;
      handleSearch(newPage);
    } else if (direction === "right" && pageLimit === false) {
      setPage(page + 1);
      newPage = page + 1;
      handleSearch(newPage);
    }
  };

  useEffect(() => {
    db.transaction((tx) => {
      tx.executeSql(
        "CREATE TABLE IF NOT EXISTS `videos` ( `id` int(11) NOT NULL,  `title` varchar(255) NOT NULL,  `description` text DEFAULT NULL,  `fileName` varchar(255) NOT NULL,  `poster` varchar(255) DEFAULT NULL,  `category` varchar(255) NOT NULL,  `base64`  BLOB NOT NULL, `MIMEType` varchar(255) DEFAULT NULL )"
      );
    });
    handleSearch(newPage);
  }, []);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.lightWhite }}>
      <Drawer.Screen
        options={{
          title: "Downloads",
          headerShown: true,
          headerLeft: () => <DrawerToggleButton />,
          drawerStyle: {
            backgroundColor: COLORS.white,
            width: 250,
          },
          headerStyle: {
            backgroundColor: "#fff",
          },
          headerTintColor: COLORS.primary,
          headerTitleStyle: {
            fontWeight: "bold",
          },
        }}
      />
      <FlatList
        data={searchResult}
        renderItem={({ item }) => (
          <NearbyJobCard
            job={item}
            handleNavigate={() =>
              router.push(`/(drawer)/downloads/video-details/${item.id}`)
            }
          />
        )}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: SIZES.medium, rowGap: SIZES.medium }}
        ListHeaderComponent={() => (
          <>
            <View style={styles.container}>
              <Text style={styles.searchTitle}>{params.id}</Text>
              <Text style={styles.noOfSearchedJobs}>
                Check all downloded video lists
              </Text>
              <Text style={styles.pageCounter}>page: {page}</Text>
            </View>
            <View style={styles.loaderContainer}>
              {searchLoader ? (
                <ActivityIndicator size="large" color={COLORS.primary} />
              ) : (
                searchError && <Text>Oops something went wrong</Text>
              )}
            </View>
          </>
        )}
        ListFooterComponent={() => (
          <View style={styles.footerContainer}>
            <TouchableOpacity
              style={styles.paginationButton}
              onPress={() => handlePagination("left")}
            >
              <Image
                source={icons.chevronLeft}
                style={styles.paginationImage}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <View style={styles.paginationTextBox}>
              <Text style={styles.paginationText}>{page}</Text>
            </View>
            <TouchableOpacity
              style={styles.paginationButton}
              onPress={() => handlePagination("right")}
            >
              <Image
                source={icons.chevronRight}
                style={styles.paginationImage}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
        )}
        stickyHeaderIndices={[0]}
      />
    </SafeAreaView>
  );
};

export default DownloadsPage;
