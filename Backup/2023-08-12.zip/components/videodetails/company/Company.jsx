import React, { useRef } from "react";
import { View, Text, Image, Button } from "react-native";

import styles from "./company.style";
import { COLORS, icons } from "../../../constants";
import { checkImageURL } from "../../../utils";

import { ResizeMode, Video } from "expo-av";
// import VideoPlayer from "expo-video-player";
// import Video from "react-native-video";
import { SERVER } from "../../../constants/url";
const Company = ({ id, title, description, poster, fileName }) => {
  const video = useRef(null);
  const [status, setStatus] = React.useState({});
  return (
    <View style={styles.container}>
      <View
        style={{
          width: "108%",
          height: 250,
          backgroundColor: COLORS.primary,
          marginTop: -25,
        }}
      >
        <Video
          ref={video}
          style={{ width: "100%", height: 250 }}
          source={{
            // uri: "https://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4",
            uri: `${SERVER.url}/videos/${fileName}`,
          }}
          useNativeControls
          resizeMode={ResizeMode.COVER}
          isLooping={false}
          shouldPlay={true}
          // onPlaybackStatusUpdate={(status) => setStatus(() => status)}
        />
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.jobName} numberOfLines={1}>
          {title}
        </Text>

        <Text style={styles.jobType}>{description}</Text>
      </View>
      {/* <View style={styles.companyInfoBox}>
        <Text style={styles.companyName}>{descrption} / </Text>
        <View style={styles.locationBox}>
          <Image
            source={icons.location}
            resizeMode="contain"
            style={styles.locationImage}
          />
          <Text style={styles.locationName}>{id}</Text>
        </View>
      </View> */}
    </View>
  );
};

export default Company;
