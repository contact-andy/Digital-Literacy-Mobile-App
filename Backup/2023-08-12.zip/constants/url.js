const SERVER = {
  url: "http://192.168.1.10:5000",
};
export { SERVER };
