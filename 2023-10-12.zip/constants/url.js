const SERVER = {
  // url: "http://192.168.84.254:5000",
  url: "http://192.168.137.1:5000",
  // url: "http://192.168.0.35:5000",
  // url: "http://10.9.155.22:5000",
};
export { SERVER };
