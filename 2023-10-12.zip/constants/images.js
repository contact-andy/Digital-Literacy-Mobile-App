import profile from "../assets/images/photo.png";
import banner from "../assets/images/banner.jpg";
import mintLogo from "../assets/images/mint.png";

export default {
  profile,
  banner,
  mintLogo,
};
