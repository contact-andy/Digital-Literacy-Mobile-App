import { Stack } from "expo-router";
export default ProfileLayout = () => {
  return <Stack></Stack>;
};
