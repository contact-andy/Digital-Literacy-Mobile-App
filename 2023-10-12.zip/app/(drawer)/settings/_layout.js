import { Stack } from "expo-router";
export default SettingsLayout = () => {
  return <Stack></Stack>;
};
