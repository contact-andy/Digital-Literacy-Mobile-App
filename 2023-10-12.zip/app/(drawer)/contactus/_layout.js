import { Stack } from "expo-router";
export default ContactusLayout = () => {
  return <Stack></Stack>;
};
